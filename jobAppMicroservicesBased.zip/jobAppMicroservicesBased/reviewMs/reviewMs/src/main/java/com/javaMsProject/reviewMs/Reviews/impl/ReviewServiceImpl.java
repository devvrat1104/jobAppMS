package com.javaMsProject.reviewMs.Reviews.impl;

import com.javaMsProject.reviewMs.Reviews.Review;
import com.javaMsProject.reviewMs.Reviews.ReviewRepository;
import com.javaMsProject.reviewMs.Reviews.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReviewServiceImpl implements ReviewService {

    @Autowired
    private ReviewRepository reviewRepository;

    @Override
    public List<Review> getReviewsByCompanyId(Long companyId) {
        return reviewRepository.findByCompanyId(companyId);
    }

    @Override
    public Review addReviewToCompany(Long companyId, Review review) {

        if(companyId == null || review == null)     return null;
        review.setCompanyId(companyId);
        return reviewRepository.save(review);
    }

    @Override
    public Review getReviewByReviewId( Long ReviewId) {
        return reviewRepository.findById(ReviewId).orElse(null);
    }

    @Override
    public boolean updateReview( Long reviewId, Review updateReview) {
        Review review = reviewRepository.findById(reviewId).orElse(null);
        if(review != null ){

            review.setContent(updateReview.getContent());
            review.setRating(updateReview.getRating());
            review.setCompanyId(updateReview.getCompanyId());
            reviewRepository.save(review);
            return true;
        }
        return false;
    }

    @Override
    public boolean deleteReview( Long reviewId) {
        Review review = reviewRepository.findById(reviewId).orElse(null);

        if (review != null ) {
            reviewRepository.deleteById(reviewId);
            return true;
        }
        return false;
    }

}
