package com.javaMsProject.reviewMs.Reviews;

import java.util.List;

public interface ReviewService {
        List<Review> getReviewsByCompanyId(Long companyId);
        Review addReviewToCompany(Long companyId, Review review);
        Review getReviewByReviewId(Long ReviewId);
        boolean updateReview( Long reviewId, Review review);
        boolean deleteReview(Long reviewId);
}
