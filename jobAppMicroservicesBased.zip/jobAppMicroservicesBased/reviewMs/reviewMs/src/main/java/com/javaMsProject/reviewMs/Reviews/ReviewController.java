package com.javaMsProject.reviewMs.Reviews;


import com.javaMsProject.reviewMs.Reviews.messaging.ReviewMessageProducer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/reviews")
public class ReviewController {

    @Autowired
    private ReviewService reviewService;
    @Autowired
    private ReviewMessageProducer reviewMessageProducer;

    @GetMapping
    public ResponseEntity<List<Review>> getAllReviewsByCompanyId(@RequestParam Long companyId) {
        return new ResponseEntity<>(reviewService.getReviewsByCompanyId(companyId), HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Review> addReviewToCompany(@RequestParam Long companyId, @RequestBody Review review) {
        Review newReview = reviewService.addReviewToCompany(companyId, review);
        if (newReview != null) {
            reviewMessageProducer.sendMessage((review));
            return new ResponseEntity<>(newReview, HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

        @GetMapping("/{reviewId}")
    public ResponseEntity<Review> getReviewByReviewId( @PathVariable Long reviewId) {
        Review review = reviewService.getReviewByReviewId( reviewId);
        if (review != null) {
            return new ResponseEntity<>(review, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/{reviewId}")
    public ResponseEntity<String> updateReview( @PathVariable Long reviewId, @RequestBody Review review) {
        boolean isReviewUpdated = reviewService.updateReview( reviewId, review);
        if (isReviewUpdated) {
            return new ResponseEntity<>("Review updated successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Company does not exists",HttpStatus.NOT_FOUND);
        }
    }
    @DeleteMapping("/{reviewId}")
    public ResponseEntity<String> deleteReview(  @PathVariable Long reviewId) {
        boolean isDeleted = reviewService.deleteReview( reviewId);
        if (isDeleted) {
            return new ResponseEntity<>("Review deleted successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Review/company not found", HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/averageRating")
    public Double getAverageRating(@RequestParam Long companyId){
        List<Review> reviewsList = reviewService.getReviewsByCompanyId(companyId);
        return reviewsList.stream().mapToDouble(Review::getRating).average().orElse(0.0);
    }
}
