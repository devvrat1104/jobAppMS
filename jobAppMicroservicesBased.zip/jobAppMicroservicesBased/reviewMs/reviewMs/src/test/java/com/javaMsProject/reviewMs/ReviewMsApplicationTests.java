package com.javaMsProject.reviewMs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReviewMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
